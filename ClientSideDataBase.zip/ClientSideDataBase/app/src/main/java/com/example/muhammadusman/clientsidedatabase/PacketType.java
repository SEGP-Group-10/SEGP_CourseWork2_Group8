package com.example.muhammadusman.clientsidedatabase;

/**
 * Created by Muhammad Usman on 3/19/2018.
 */

public enum PacketType {
    LOGIN,SIGNUP,MASSAGE
}
