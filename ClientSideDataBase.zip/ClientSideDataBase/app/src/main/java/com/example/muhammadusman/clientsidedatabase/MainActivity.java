package com.example.muhammadusman.clientsidedatabase;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    DataBaseManager db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new DataBaseManager(this);
        byte[] c=null;
        SignUp signup = new SignUp("SSS","Muhammad ","Usman","1111",c,"AAA");
        db.putUser_Info(db,signup);

        byte[] b=null;
        Massage massage=new Massage("1234533","54321","HelloTest Again",b);
        db.Put_Messages(db,massage);


    }
}
