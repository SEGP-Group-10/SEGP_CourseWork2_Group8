package com.example.muhammadusman.clientsidedatabase;

/**
 * Created by Muhammad Usman on 3/19/2018.
 */

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.sql.*;

/**
 * Created by Muhammad Usman on 3/17/2018.
 */

public class DataBaseManager extends SQLiteOpenHelper {
    private Statement st = null;
    private ResultSet rs = null;
    SignUp signup = new SignUp();
    // String User_No = signup.getUserNo();
    public static final String DataBaseName = "ClientSide.db";
    public static final String TableName = "users";
    public static final String Table_Name2 = "messages";
    public static final String Col1 =  "user_No";
    public static final String Col2 =  "First_Name";
    public static final String Col3 =  "Last_Name";
    public static final String Col4 =  "PASSWORD";
    public static final String Col5 =  "img";
    public static final  String Col6 =  "status";
    public static final  String Col7 = "Sender_No";
    public static final String Col8 = "Receiver_No";
    public static final String Col9 = "Text_Data";
    public static final String Col10 = "Img_Data";
    static final String Table_CREATE_Users = "create table"+TableName+
            "(user_No String primary key NOT NULL"+",First_Name text NOT NULL,Last_Name text NOT NULL,PASSWORD text NOT NULL,img longblob,status  text)";
    static final String Table_CREATE_Messages = "create table  messages "+
            "(Sender_No String NOT NULL ,Receiver_No String NOT NULL,Text_Data text NOT NULL,img_Data longblob)";
    public DataBaseManager(Context context) {
        super(context,DataBaseName , null, 1);
        Log.d("Database Aa","Database Created");
    }

    @Override
    public void onCreate(SQLiteDatabase sqdb) {
        sqdb.execSQL(Table_CREATE_Users);
        Log.d("Database Operation","Database Created");
        System.out.println("Hello");
        sqdb.execSQL(Table_CREATE_Messages);
        Log.d("Database Operation","Database Created");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        onCreate(sqLiteDatabase);
    }

    public void putUser_Info(DataBaseManager dop,SignUp signup) {
        byte c[] = signup.getImage();
        String UserNo = signup.getUserNo();
        System.out.println("" + signup.getUserNo());
        // if (isUserNoValid(UserNo)) {
        String First_Name = signup.getFirstName();
        String Last_Name = signup.getLastName();
        String Password = signup.getpassword();
        String Status = signup.getStatus();

        SQLiteDatabase sq = dop.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(Col1,UserNo);
        cv.put(Col2, First_Name);
        cv.put(Col3, Last_Name );
        cv.put(Col4, Password);
        cv.put(Col6, Status);
        cv.put(Col5, c);
        long result = sq.insert(TableName, null, cv);
        if (result == -1) {
            System.out.println("Sorry Retry");
        } else {
            Log.d("Database Operation", "Values Inserted");
        }
       /* } else
        {
            System.out.println("Please retry");
        }*/
    }


    public void Put_Messages(DataBaseManager dop , Massage message ){

        String Sender_Name = message.getSenderNo();
        String Recevier_Name = message.getReceiverNo();
        String Chat = message.getTextData();
        byte b [] = message.getImageData();
        SQLiteDatabase sq = dop.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(Col7,Sender_Name);
        cv.put(Col8,Recevier_Name);
        cv.put(Col9,Chat);
        cv.put(Col10,b);
        long result = sq.insert(Table_Name2, null, cv);
        if (result == -1) {
            System.out.println("Sorry Retry");
        } else {
            Log.d("Database Operation", "Values Inserted");
        }
    }

    public boolean isUserNoValid(String userNo){
        try {

            rs=st.executeQuery("select user_no from users where user_no='user_No'");
            while(rs.next()){
                if(rs.getString(1).equals(userNo)){
                    return false;
                }
            }
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return true;
    }


}
