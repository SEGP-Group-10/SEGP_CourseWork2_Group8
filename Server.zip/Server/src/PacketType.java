public enum PacketType {
    LOGIN,SIGNUP,MASSAGE
}