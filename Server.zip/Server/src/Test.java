
public class Test {

    public static void main(String[] args){
        byte c [] =null;
    	SignUp signup = new SignUp("SSS","Muhammad ","Usman","1111",c,"AAA");
        byte[] b=null;
        Massage massage=new Massage("1234533","54321","HelloTest Again",b);

        DatabaseManager db=new DatabaseManager();
        db.addNewMassage(massage);
        db.addNewUser(signup);
    }
}