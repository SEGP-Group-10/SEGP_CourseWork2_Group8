package com.example.muzammil.prolife;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class Contacts extends Fragment {


    private RecyclerView mContactsList;
    private View mMainView;

    // Firebase
    FirebaseAuth mAuth;
    DatabaseReference mFriendsDatabase;
    DatabaseReference mUsersDatabase;

    String mCurrent_user_id;

    public Contacts() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        mMainView=inflater.inflate(R.layout.fragment_contacts, container, false);

        mContactsList=(RecyclerView) mMainView.findViewById(R.id.contacts_list);

        mAuth = FirebaseAuth.getInstance();

        mCurrent_user_id = mAuth.getCurrentUser().getUid();

        mFriendsDatabase = FirebaseDatabase.getInstance().getReference().child("Contacts").child(mCurrent_user_id);
        mFriendsDatabase.keepSynced(true);
        mUsersDatabase = FirebaseDatabase.getInstance().getReference().child("Users");
        mUsersDatabase.keepSynced(true);


        mContactsList.setHasFixedSize(true);
        mContactsList.setLayoutManager(new LinearLayoutManager(getContext()));


        return mMainView;
    }

    @Override
    public void onStart() {
        super.onStart();

        FirebaseRecyclerAdapter<Contact,ContactsViewHolder> firebaseRecyclerAdapter=new FirebaseRecyclerAdapter<Contact, ContactsViewHolder>(Contact.class,R.layout.single_contact_layout,ContactsViewHolder.class,mFriendsDatabase) {
            @Override
            protected void populateViewHolder(final ContactsViewHolder viewHolder, Contact model, int position) {
//                viewHolder.setName("Some Name");
//                viewHolder.setStatus("My Status");

                final String list_user_id = getRef(position).getKey();

                Log.d("Contacts","Contact Id: "+list_user_id);

                mUsersDatabase.child(list_user_id).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        final String userName = dataSnapshot.child("name").getValue().toString();
                        final String userThumb = dataSnapshot.child("thumb_image").getValue().toString();
                        String userStatus=dataSnapshot.child("status").getValue().toString();
                        final Boolean userOnline=(Boolean) dataSnapshot.child("online").getValue();

                        Log.d("Contacts","Contact name: "+userName);
                        Log.d("Contacts","Contact status: "+userStatus);
                        Log.d("Contacts","Contact image: "+userThumb);
                        //

                        viewHolder.setName(userName);
                        viewHolder.setStatus(userStatus);
                        viewHolder.setUserImage(userThumb, getContext());
                        viewHolder.setUserOnline(userOnline);

                        viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {

                                CharSequence options[] = new CharSequence[]{"Open Profile", "Send message"};

                                final AlertDialog.Builder builder = new AlertDialog.Builder(getContext());

                                builder.setTitle("Select Options");
                                builder.setItems(options, new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {

                                        //Click Event for each item.
                                        if(i == 0){

                                           /* Intent profileIntent = new Intent(getContext(), ProfileActivity.class);
                                            profileIntent.putExtra("user_id", list_user_id);
                                            startActivity(profileIntent);*/

                                        }

                                        if(i == 1){

                                            Intent chatIntent = new Intent(getContext(), chatActivity.class);
//                                            chatIntent.putExtra("user_id", list_user_id);
                                            chatIntent.putExtra("user_name", userName);
                                            chatIntent.putExtra("user_image", userThumb);
                                            chatIntent.putExtra("isOnline",userOnline);
                                            chatIntent.putExtra("userId",list_user_id);
                                            chatIntent.putExtra("currentUserId",mCurrent_user_id);
                                            startActivity(chatIntent);

                                        }

                                    }
                                });

                                builder.show();

                            }
                        });

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }
        };

        mContactsList.setAdapter(firebaseRecyclerAdapter);
    }

    public static class ContactsViewHolder extends RecyclerView.ViewHolder {

        View mView;

        public ContactsViewHolder(View itemView) {
            super(itemView);

            mView = itemView;

        }

        public void setStatus(String status){

            TextView userStatusView = (TextView) mView.findViewById(R.id.single_user_status);
            userStatusView.setText(status);

        }

        public void setName(String name){

            TextView userNameView = (TextView) mView.findViewById(R.id.single_user_name);
            userNameView.setText(name);

        }

        public void setUserImage(String thumb_image, Context context){

            CircleImageView userImageView = (CircleImageView) mView.findViewById(R.id.single_user_image);
            Picasso.with(context).load(thumb_image).placeholder(R.drawable.default_avatar).into(userImageView);

        }

        public void setUserOnline(Boolean isOnline){
            CircleImageView userOnlineImage = (CircleImageView) mView.findViewById(R.id.user_online);

            if(isOnline==true){
                userOnlineImage.setVisibility(View.VISIBLE);
            }else {
                userOnlineImage.setVisibility(View.INVISIBLE);
            }
        }

    }


}
