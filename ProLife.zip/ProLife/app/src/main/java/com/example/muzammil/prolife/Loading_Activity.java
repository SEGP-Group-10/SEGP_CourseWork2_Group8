package com.example.muzammil.prolife;

import android.graphics.drawable.AnimationDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ProgressBar;


public class Loading_Activity extends AppCompatActivity {

    AnimationDrawable anim;

    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loading_);

//        progressBar=findViewById(R.id.progressBar);



//        ImageView iv = (ImageView) findViewById(R.id.iv);
//        iv.setBackgroundResource(R.drawable.load);
//        anim = (AnimationDrawable) iv.getBackground();
//
//        anim.start();
    }
}
