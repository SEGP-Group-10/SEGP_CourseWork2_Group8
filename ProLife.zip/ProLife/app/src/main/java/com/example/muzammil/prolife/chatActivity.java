package com.example.muzammil.prolife;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ServerValue;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;


public class chatActivity extends AppCompatActivity {

    private String chatUser;
    private String userImage;
    private Boolean isOnline;

    private Toolbar chatToolbar;

    private CircleImageView userImageView;
    private TextView chatUserName;
    private TextView isUserOnline;

    // Linear Layout Activity_chat
    private ImageButton sendImageButton;
    private EditText chatMessage;


    // Firebase
    public String userChatWithId;
    public String currentUserId;

    public DatabaseReference messageDatabase;
    public DatabaseReference chatDatabase;

    //Message Recycler View
    private RecyclerView mMessagesList;
    private SwipeRefreshLayout mRefreshLayout;

    private final List<Message> messagesList = new ArrayList<>();
    private LinearLayoutManager mLinearLayout;
    private MessageAdapter mAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

        chatToolbar = (Toolbar) findViewById(R.id.chatappbar);
        setSupportActionBar(chatToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        ActionBar actionBar = getSupportActionBar();

        actionBar.setDisplayHomeAsUpEnabled(true);
        actionBar.setDisplayShowCustomEnabled(true);


        chatUser = getIntent().getStringExtra("user_name");
        userImage=getIntent().getStringExtra("user_image");
        isOnline=getIntent().getBooleanExtra("isOnline",false);
        userChatWithId=getIntent().getStringExtra("userId");
        currentUserId=getIntent().getStringExtra("currentUserId");


        LayoutInflater inflater = (LayoutInflater) this.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View action_bar_view = inflater.inflate(R.layout.chat_custom_bar, null);

        actionBar.setCustomView(action_bar_view);

        userImageView = (CircleImageView) action_bar_view.findViewById(R.id.custom_bar_image);
        chatUserName=(TextView) action_bar_view.findViewById(R.id.custom_bar_title);
        isUserOnline=(TextView) action_bar_view.findViewById(R.id.custom_bar_seen);

        Picasso.with(this).load(userImage).placeholder(R.drawable.default_avatar).into(userImageView);

        chatUserName.setText(chatUser);
        if(isOnline){
            isUserOnline.setText("Online");
        }else {
            isUserOnline.setText("Offline");
        }


        // Message
        sendImageButton=(ImageButton) findViewById(R.id.send_image_button);
        chatMessage=(EditText) findViewById(R.id.chat_massage);

        //Firebase Init
        messageDatabase=FirebaseDatabase.getInstance().getReference().child("messages");
        chatDatabase=FirebaseDatabase.getInstance().getReference().child("chats");

        // Message Recycler View
        mAdapter = new MessageAdapter(messagesList);

        mMessagesList = (RecyclerView) findViewById(R.id.massageList);
        //mRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.message_swipe_layout);
        mLinearLayout = new LinearLayoutManager(this);

        mMessagesList.setHasFixedSize(true);
        mMessagesList.setLayoutManager(mLinearLayout);

        mMessagesList.setAdapter(mAdapter);


        // Loding Messages from Firebase Database
        loadMessages();

        // Sending a message
        sendImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                sendMessage();

            }
        });





        getSupportActionBar().setTitle(chatUser);
    }

    private void sendMessage() {

        String message=chatMessage.getText().toString();

        if(!message.isEmpty()){
            String current_user_ref = currentUserId + "/" + userChatWithId;
            String chat_user_ref = userChatWithId + "/" + currentUserId;

            DatabaseReference userMessagePush = FirebaseDatabase.getInstance().getReference().child("messages")
                    .child(currentUserId).child(userChatWithId).push();

            String message_push_id = userMessagePush.getKey();

            Map messageMap = new HashMap();
            messageMap.put("message", message);
            messageMap.put("seen", false);
            messageMap.put("type", "text");
            messageMap.put("time", ServerValue.TIMESTAMP);
            messageMap.put("from", currentUserId);

            Map messageUserMap = new HashMap();
            messageUserMap.put(current_user_ref + "/" + message_push_id, messageMap);
            messageUserMap.put(chat_user_ref + "/" + message_push_id, messageMap);

            chatMessage.setText("");

            chatDatabase.child(currentUserId).child(userChatWithId).child("seen").setValue(true);
            chatDatabase.child(currentUserId).child(userChatWithId).child("timestamp").setValue(ServerValue.TIMESTAMP);

            chatDatabase.child(userChatWithId).child(currentUserId).child("seen").setValue(false);
            chatDatabase.child(userChatWithId).child(currentUserId).child("timestamp").setValue(ServerValue.TIMESTAMP);

            messageDatabase.updateChildren(messageUserMap, new DatabaseReference.CompletionListener() {
                @Override
                public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {

                    if(databaseError != null){

                        Log.d("CHAT_LOG", databaseError.getMessage().toString());

                    }

                }
            });
        }

    }

    private void loadMessages() {

        DatabaseReference messageRef = messageDatabase.child(currentUserId).child(userChatWithId);

        //Query messageQuery = messageRef.limitToLast(mCurrentPage * TOTAL_ITEMS_TO_LOAD);


        messageRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                Message message = dataSnapshot.getValue(Message.class);

                /*itemPos++;

                if(itemPos == 1){

                    String messageKey = dataSnapshot.getKey();

                    mLastKey = messageKey;
                    mPrevKey = messageKey;

                }*/

                messagesList.add(message);
                mAdapter.notifyDataSetChanged();

                mMessagesList.scrollToPosition(messagesList.size() - 1);

                //mRefreshLayout.setRefreshing(false);
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }


    // Message Adatpter class for Message Recycler View

    public class MessageAdapter extends RecyclerView.Adapter<MessageAdapter.MessageViewHolder>{


        private List<Message> mMessageList;
        private DatabaseReference mUserDatabase;

        public MessageAdapter(List<Message> mMessageList) {

            this.mMessageList = mMessageList;

        }

        @Override
        public MessageViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.single_message_layout ,parent, false);

            return new MessageViewHolder(v);

        }

        public class MessageViewHolder extends RecyclerView.ViewHolder {

            public TextView messageText;
            public CircleImageView profileImage;
            public ImageView messageImage;

            public MessageViewHolder(View view) {
                super(view);

                messageText = (TextView) view.findViewById(R.id.message_text_layout);
                profileImage = (CircleImageView) view.findViewById(R.id.message_profile_layout);
                messageImage = (ImageView) view.findViewById(R.id.message_image_layout);

            }
        }

        @Override
        public void onBindViewHolder(final MessageViewHolder viewHolder, int i) {

            Message c = mMessageList.get(i);

            String from_user = c.getFrom();
            String message_type = c.getType();

            /*Picasso.with(viewHolder.profileImage.getContext()).load(userImage)
                    .placeholder(R.drawable.default_avatar).into(viewHolder.profileImage);
*/
            mUserDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child(from_user);
            mUserDatabase.keepSynced(true);
            mUserDatabase.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    String image = dataSnapshot.child("thumb_image").getValue().toString();

                    Picasso.with(viewHolder.profileImage.getContext()).load(image)
                            .placeholder(R.drawable.default_avatar).into(viewHolder.profileImage);

                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });

            if(message_type.equals("text")) {

                viewHolder.messageText.setText(c.getMessage());
                viewHolder.messageImage.setVisibility(View.INVISIBLE);
                //viewHolder.messageText.setTextColor(ColorStateList.PARCELABLE_WRITE_RETURN_VALUE);


            } else {

                viewHolder.messageText.setVisibility(View.INVISIBLE);
                Picasso.with(viewHolder.profileImage.getContext()).load(c.getMessage())
                        .placeholder(R.drawable.default_avatar).into(viewHolder.messageImage);

            }

            if(from_user.equals(currentUserId)){
                viewHolder.messageText.setTextColor(Color.WHITE);
                viewHolder.messageText.setBackgroundColor(Color.BLUE);


                //viewHolder.profileImage.setPadding(100,0,0,0);
            }else {

                viewHolder.messageText.setTextColor(Color.MAGENTA);
                viewHolder.messageText.setBackgroundColor(Color.GREEN);

                //viewHolder.profileImage.setPadding(0,0,0,0);
            }

        }

        @Override
        public int getItemCount() {
            return mMessageList.size();
        }

    }

}
