package com.example.muzammil.prolife;

/**
 * Created by muzammil on 4/17/18.
 */

public class Contact {

    private String date;

    public Contact(){

    }

    public Contact(String date) {
        this.date = date;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
