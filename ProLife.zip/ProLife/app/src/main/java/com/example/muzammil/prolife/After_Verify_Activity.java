package com.example.muzammil.prolife;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class After_Verify_Activity extends AppCompatActivity {

    private static final int PICK_IMAGE=200;
    Uri ImageURI;
    ImageView imageView;

    EditText name, status;

    FirebaseAuth mAuth;
    DatabaseReference mUserDatabase;

    private String current_userId;

    ProgressDialog mRegProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_after__verify_);

        final String phoneNo = getIntent().getStringExtra("phoneNo");

        imageView = (ImageView) findViewById(R.id.user_image);
        imageView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                OpenGallery();
            }
        });

        name=findViewById(R.id.name);
        status=findViewById(R.id.status);

        // Firebase init code
        mAuth=FirebaseAuth.getInstance();
        current_userId=mAuth.getCurrentUser().getUid().toString();
        mUserDatabase= FirebaseDatabase.getInstance().getReference().child("Users").child(current_userId);
        //

        final Button button = (Button) findViewById(R.id.finishButton);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                mRegProgress=new ProgressDialog(After_Verify_Activity.this);
                mRegProgress.setTitle("Registering User");
                mRegProgress.setMessage("Please wait while we create your account !");
                mRegProgress.setCanceledOnTouchOutside(false);
                mRegProgress.show();

                String uName=name.getText().toString();
                String uStatus=status.getText().toString();

                if(uName.equals("")){
                    name.setError("Please enter your name!");
                }else
                {
                    if(uStatus.equals("")){
                        uStatus="Hey there, I a'm using ProLife Chat app.";
                    }
                    Map userData=new HashMap<String,String>();
                    userData.put("name",uName);
                    userData.put("status",uStatus);
                    userData.put("image","default");
                    userData.put("thumb_image","default");
                    userData.put("phone",phoneNo);

                    mUserDatabase.updateChildren(userData).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            mRegProgress.dismiss();

                            Intent mainIntent = new Intent(After_Verify_Activity.this, Home.class);
                            mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            startActivity(mainIntent);
                            finish();
                        }
                    });

                }

                //Intent intent = new Intent(After_Verify_Activity.this, Home.class);
                //startActivity(intent);
            }
        });

    }
    private void OpenGallery(){
        Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        startActivityForResult(gallery, PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode== RESULT_OK && requestCode == PICK_IMAGE){

            // Image crop etc is remaining
            ImageURI = data.getData();
            imageView.setImageURI(ImageURI);
        }

    }
}
