package com.example.muzammil.prolife;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.database.DatabaseReference;

import java.util.concurrent.TimeUnit;

public class MainActivity extends AppCompatActivity {

    FirebaseAuth authr;

    EditText phoneNumber, verifyCode;
    public String codeSent;

    Button getCodeBtn, verifyCodeBtn;

    private ProgressDialog progressDialog;
    private ProgressDialog verify_progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        if(authr.getInstance().getCurrentUser()!=null){
            Intent intent=new Intent(MainActivity.this,Home.class);
            startActivity(intent);
            finish();
        }

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        authr= FirebaseAuth.getInstance();

        phoneNumber=findViewById(R.id.phoneNumber);
        verifyCode=findViewById(R.id.verifyCode);

        phoneNumber.setText("+923");

        getCodeBtn=findViewById(R.id.getCodeBtn);
        verifyCodeBtn=findViewById(R.id.verifyCodeBtn);

        progressDialog=new ProgressDialog(this);
        progressDialog.setTitle("Sending Code");
        progressDialog.setMessage("Please wait while we send you code!");
        progressDialog.setCanceledOnTouchOutside(false);


        verify_progressDialog=new ProgressDialog(this);
        verify_progressDialog.setTitle("Verifying Code");
        verify_progressDialog.setMessage("Please wait while are Verifying code!");
        verify_progressDialog.setCanceledOnTouchOutside(false);

        getCodeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String p="+923";

                String phoneNum = phoneNumber.getText().toString();

                if(phoneNum.startsWith(p) && phoneNum.length()==13) {
                    progressDialog.show();
                    getCodeBtn.setText("Resend Code");
                    sendCode(phoneNum);

                }else {
                    phoneNumber.setError("Phone Number Required");
                }
            }
        });

        verifyCodeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                verifyCode();
                verify_progressDialog.show();
            }
        });

    }

    private void verifyCode(){
        String code = verifyCode.getText().toString();

        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(codeSent, code);
        signInWithPhoneAuthCredential(credential);
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        authr.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {

                            Intent intent=new Intent(MainActivity.this,After_Verify_Activity.class);
                            intent.putExtra("phoneNo",phoneNumber.getText().toString());
                            startActivity(intent);
                            finish();

                            verify_progressDialog.cancel();

                            //Toast.makeText(getApplicationContext(), "Login Successfull", Toast.LENGTH_LONG).show();

                        } else {
                            if(task.getException() instanceof FirebaseAuthInvalidCredentialsException){
                                //Toast.makeText(getApplicationContext(), "Incorrect Code", Toast.LENGTH_LONG).show();
                                verifyCode.setError("Incorrect Code");
                                verify_progressDialog.dismiss();
                            }
                        }

                    }
                });
    }

//        String test="12349787866";
//        Boolean isTrue=test.startsWith("00923");}
    private void sendCode(String phoneNum){


        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phoneNum,
                60,
                TimeUnit.SECONDS,
                this,
                mCallbacks);

    }

    PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {

        }

        @Override
        public void onVerificationFailed(FirebaseException e) {

        }

        @Override
        public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(s, forceResendingToken);
            codeSent = s;
            progressDialog.dismiss();
        }

    };

}


