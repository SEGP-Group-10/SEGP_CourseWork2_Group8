package com.example.mega_providers.segp;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.app.FragmentStatePagerAdapter;

/**
 * Created by MeGa_PrOviders on 3/29/2018.
 */

public class PageAdapter extends FragmentPagerAdapter {

    private int mNumOftabs;
    public PageAdapter(FragmentManager fm, int NumofTabs) {
        super(fm);
        this.mNumOftabs = NumofTabs;
    }

    @Override
    public Fragment getItem(int position) {

        switch (position){
            case 0:
                Chats tab1 = new Chats();
                return tab1;
            case 1:
                Chats tab2 = new Chats();
                return tab2;
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return mNumOftabs;
    }
}
