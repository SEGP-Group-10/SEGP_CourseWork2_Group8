package com.example.muhammadusman.client_database_side;

/**
 * Created by Muhammad Usman on 3/18/2018.
 */

public enum PacketType {
    LOGIN,SIGNUP,MASSAGE
}
