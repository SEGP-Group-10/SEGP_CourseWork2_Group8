package com.example.muzammil.prolife;


/**
 * Created by muzammil on 4/16/18.
 */

public class MyLocalContacts {

    private String name;
    private String phone;
    private String status;

    public MyLocalContacts(){

    }

    public MyLocalContacts(String name, String phone) {
        this.name = name;
        this.phone = phone;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }


}
