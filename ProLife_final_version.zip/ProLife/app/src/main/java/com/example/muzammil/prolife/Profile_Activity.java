package com.example.muzammil.prolife;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

public class Profile_Activity extends AppCompatActivity {

    CircleImageView userImage;
    TextView userName,userPhone,userStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_);

        String name=getIntent().getStringExtra("userName");
        String phone=getIntent().getStringExtra("userPhone");
        String status=getIntent().getStringExtra("userStatus");
        String imageSrc=getIntent().getStringExtra("userImage");

        userImage=(CircleImageView) findViewById(R.id.user_profile_image);
        userName=(TextView) findViewById(R.id.display_name);
        userPhone=(TextView) findViewById(R.id.phone);
        userStatus=(TextView) findViewById(R.id.status);

        // Display user data

        userName.setText(name);
        userPhone.setText(phone);
        userStatus.setText(status);

        Picasso.with(this).load(imageSrc).placeholder(R.drawable.default_avatar).into(userImage);





    }
}
