package com.example.muzammil.prolife;

import com.google.firebase.database.ServerValue;

/**
 * Created by muzammil on 4/19/18.
 */

public class Chat {

    private long timeStamp;

    public Chat() {
    }

    public Chat(long timeStamp) {
        this.timeStamp = timeStamp;
    }

    public long getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(long timeStamp) {
        this.timeStamp = timeStamp;
    }
}
