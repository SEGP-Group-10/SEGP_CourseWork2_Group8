package com.example.muzammil.prolife;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;

import static android.content.ContentValues.TAG;


public class ChatsTab extends Fragment {

    private RecyclerView mChatsList;
    private View mMainView;

    // Firebase
    FirebaseAuth mAuth;
    DatabaseReference mChatsDatabase;
    DatabaseReference mUsersDatabase;

    String mCurrent_user_id;

    public ChatsTab() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        mMainView=inflater.inflate(R.layout.fragment_chats, container, false);
        Log.d("ChatsTab","mMain View Create.");

        mChatsList=(RecyclerView) mMainView.findViewById(R.id.chats_list);
        mChatsList.setHasFixedSize(true);
        mChatsList.setLayoutManager(new LinearLayoutManager(getContext()));
        Log.d("ChatsTab","Recycler View Created");

        mAuth = FirebaseAuth.getInstance();

        mCurrent_user_id = mAuth.getCurrentUser().getUid();
        Log.d("ChatsTab","mAuth & currentUserId created");

        mChatsDatabase = FirebaseDatabase.getInstance().getReference().child("chats").child(mCurrent_user_id);
        mChatsDatabase.keepSynced(true);
        mUsersDatabase = FirebaseDatabase.getInstance().getReference().child("Users");
        mUsersDatabase.keepSynced(true);

        Log.d("ChatsTab","Database reference Created");

        //Displaying Chat list
        displayChatList();

        return mMainView;
    }

    @Override
    public void onStart() {
        super.onStart();

        //displayChatList();
    }



    @Override
    public void onResume() {
        super.onResume();

    }

    public void displayChatList(){

        FirebaseRecyclerAdapter<Message,ChatsViewHolder> firebaseRecyclerAdapter=new FirebaseRecyclerAdapter<Message, ChatsViewHolder>(Message.class, R.layout.single_contact_layout, ChatsViewHolder.class,mChatsDatabase) {
            @Override
            protected void populateViewHolder(final ChatsViewHolder viewHolder, Message model, int position) {

                final String list_user_id = getRef(position).getKey();

                String message=model.getMessage();
                viewHolder.setMessage(message);

                mUsersDatabase.child(list_user_id).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        final String userName = dataSnapshot.child("name").getValue().toString();
                        final String userThumb = dataSnapshot.child("thumb_image").getValue().toString();
                        final Boolean userOnline=(Boolean) dataSnapshot.child("online").getValue();


                        viewHolder.setName(userName);
                        viewHolder.setUserImage(userThumb, getContext());
                        viewHolder.setUserOnline(userOnline);

                        viewHolder.mView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                Intent chatIntent = new Intent(getContext(), chatActivity.class);
                                chatIntent.putExtra("user_name", userName);
                                chatIntent.putExtra("user_image", userThumb);
                                chatIntent.putExtra("isOnline",userOnline);
                                chatIntent.putExtra("userId",list_user_id);
                                chatIntent.putExtra("currentUserId",mCurrent_user_id);
                                startActivity(chatIntent);
                            }
                        });
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });


            }
        };

        mChatsList.setAdapter(firebaseRecyclerAdapter);

    }

    public static class ChatsViewHolder extends RecyclerView.ViewHolder {

        View mView;

        public ChatsViewHolder(View itemView) {
            super(itemView);

            mView = itemView;

        }

        public void setMessage(String message){

            String shortMessage;
            Log.d(TAG, "setMessage: ");
            if(message.length()>50){
                shortMessage=message.substring(0,40) + " ...";
            }else {
                shortMessage=message;
            }

            TextView userMessageView = (TextView) mView.findViewById(R.id.single_user_status);
            userMessageView.setText(shortMessage);

        }

        public void setName(String name){

            TextView userNameView = (TextView) mView.findViewById(R.id.single_user_name);
            userNameView.setText(name);

        }

        public void setUserImage(String thumb_image, Context context){

            CircleImageView userImageView = (CircleImageView) mView.findViewById(R.id.single_user_image);
            Picasso.with(context).load(thumb_image).placeholder(R.drawable.default_avatar).into(userImageView);

        }

        public void setUserOnline(Boolean isOnline){
            CircleImageView userOnlineImage = (CircleImageView) mView.findViewById(R.id.user_online);

            if(isOnline==true){
                userOnlineImage.setVisibility(View.VISIBLE);
            }else {
                userOnlineImage.setVisibility(View.INVISIBLE);
            }
        }

    }

}
