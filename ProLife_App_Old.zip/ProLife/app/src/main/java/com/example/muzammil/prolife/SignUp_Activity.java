package com.example.muzammil.prolife;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.muzammil.prolife.commclasses.Packet;
import com.example.muzammil.prolife.commclasses.PacketType;
import com.example.muzammil.prolife.commclasses.Response;
import com.example.muzammil.prolife.commclasses.ResponseType;
import com.example.muzammil.prolife.commclasses.SignUp;

public class SignUp_Activity extends AppCompatActivity {

    private Button signUpButton;
    private EditText name;
    private EditText userNo;
    private EditText password;
    private EditText repassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        name = (EditText) findViewById(R.id.name);
        userNo = (EditText) findViewById(R.id.userNo);
        password = (EditText) findViewById(R.id.password);
        repassword = (EditText) findViewById(R.id.repassword);

    }

    public void signUpButtonClicked(View view){

        String user_no=userNo.getText().toString();
        String user_name=name.getText().toString();
        String user_password=password.getText().toString();
        String user_repassword=repassword.getText().toString();

        Boolean isValidName=isValidName(user_name);
        Boolean isValidNo=isValidNo(user_no);
        Boolean isValidPassword=isValidPassword(user_password);
        Boolean isValidRepassword=isValidRepassword(user_repassword);

        if(isValidName && isValidNo && isValidPassword && isValidRepassword){
            MainActivity.outgoingPackets.add(new Packet(PacketType.SIGNUP,new SignUp(user_no,user_password,user_name,null,null)));

            while (MainActivity.incomingPackets.size()==0){

            }

            if(MainActivity.incomingPackets.size()>0){
                Log.d("Socket","Incomming packet > 0");
                Packet packet=MainActivity.incomingPackets.get(0);

                if(packet.getType()== PacketType.SIGNUP_RESPONSE){
                    Log.d("Socket","packet tupe is signup response");
                    Response response= (Response) packet.getData();
                    if(response.getResponseType()==ResponseType.OK){
                        Log.d("Socket","packet tupe is signup response is OOOOOKKKKKK");
                        Intent intent = new Intent(this.getApplicationContext(), Home_Activity.class);
                        startActivity(intent);
                    }
                }
            }
        }

    }

    public Boolean isValidName(String Name){
        if(Name.length()==0){
            name.setError("Please enter a name!");
            return false;
        }else {
            return true;
        }
    }

    public Boolean isValidNo(String no){
        if(no.length()>11 || no.length()<11 || no.charAt(0)!='0' || no.charAt(1)!='3'){
            userNo.setError("Please enter a correct no!");
            return false;
        }else {
            return true;
        }
    }

    public Boolean isValidPassword(String pass){
        if(pass.length()<8){
            password.setError("Please enter a 8 character password!");
            return false;
        }else {
            return true;
        }
    }

    public Boolean isValidRepassword(String rePass){
        if(!rePass.equals(password.getText().toString())){
            repassword.setError("Password not match!");
            return false;
        }else {
            return true;
        }
    }
}
