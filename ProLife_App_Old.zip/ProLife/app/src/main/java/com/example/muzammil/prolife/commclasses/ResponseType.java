package com.example.muzammil.prolife.commclasses;

public enum ResponseType {
    OK,ERROR,SIGNUP_OK,SIGNUP_INVALID_NO
}
