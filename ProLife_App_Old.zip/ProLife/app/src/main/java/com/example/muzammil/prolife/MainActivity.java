package com.example.muzammil.prolife;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.muzammil.prolife.commclasses.*;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    //TestSocket s;

    Socket s;

    ObjectInputStream inputStream;
    ObjectOutputStream outputStream;


    private Button signIn, signUp;
    private TextView Forgot_Password;
    public static MyDBHandler DBHandler;

    public static ArrayList<Packet> incomingPackets;
    public static ArrayList<Packet> outgoingPackets;


    public MainActivity(){
        DBHandler=new MyDBHandler(this,null,null,1);
        incomingPackets=new ArrayList<Packet>();
        outgoingPackets=new ArrayList<Packet>();
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
    //    s=new TestSocket();
    //    s.execute();

        SocketThread socketThread=new SocketThread();
        socketThread.start();

        Thread socketThead=new Thread(new Runnable() {
            @Override
            public void run() {


                try {
                    s=new Socket("192.168.40.198",8888);
                    Log.d("Socket","Conection created: "+s.isConnected());
                    inputStream=new ObjectInputStream(s.getInputStream());
                    Log.d("Socket","InputStream obj created: ");
                    outputStream=new ObjectOutputStream(s.getOutputStream());
                    Log.d("Socket","outputStream obj created: ");

            /*Thread readingThread=new Thread(readSocket);
            readingThread.start();
            Log.d("Socket","Reading Thread created: ");

            Thread writingThread=new Thread(writeSocket);
            writingThread.start();
            Log.d("Socket","Writing Thread created: ");

            while (readingThread.isAlive() || writingThread.isAlive()){

            }*/

                    Log.d("Socket","After Threads death.");

                    inputStream.close();
                    outputStream.close();
                    s.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                while (true){

                }
            }
        });
        //socketThead.start();

       // Boolean is=DBHandler.removeUserInfo(DBHandler);
       /*Contact contact=DBHandler.getContact(DBHandler,1);

       if(contact==null){
           Log.d("Database Operation","Contact is null");
       }*/

        //MyDBHandler DBHandler=new MyDBHandler(this,null,null,1);

    /*    SignUp signUp1=new SignUp("03002807360","12345","Muzammil",null,"Just Chill");

        Boolean addInfo=DBHandler.addUserInfo(DBHandler,signUp1);
        Log.d("Database Operation","Is user info added: "+addInfo);
        Boolean updateInfo=DBHandler.updateUserInfo(DBHandler,signUp1);
        Log.d("Database Operation","Is user info updated: "+updateInfo);

        SignUp signUpTest=DBHandler.getUserInfo(DBHandler);

        Log.d("Database Operation","User No: "+signUpTest.getUserNo());
        Log.d("Database Operation","Name: "+signUpTest.getName());
        Log.d("Database Operation","Password: "+signUpTest.getPassword());
        Log.d("Database Operation","Status: "+signUpTest.getStatus());

        Boolean isLogedIn=DBHandler.isUserLogedIn(DBHandler);
        Log.d("Database Operation","Is user Loged In: "+isLogedIn);

        Boolean setLoginInfo=DBHandler.setUserLogedInInfo(DBHandler,"false","3002807360");
        Log.d("Database Operation","Is user seting Loged In: "+setLoginInfo);

        isLogedIn=DBHandler.isUserLogedIn(DBHandler);
        Log.d("Database Operation","Is user Loged In: "+isLogedIn);

    */
//        Boolean test=DBHandler.addNewMassage(DBHandler,new Massage("12345","54321","Database Testing",img));

        /*ArrayList<Massage> arrayList=DBHandler.getListMassages(DBHandler,"12345","54321");

        for(Massage s: arrayList){
            Log.d("Database Operation","Massage Id: "+s.getMassageId());
            Log.d("Database Operation","Massage Sender: "+s.getSenderNo());
            Log.d("Database Operation","Massage Receiver: "+s.getReceiverNo());
            Log.d("Database Operation","Massage Data: "+s.getTextData());
        }
        */
        //Massage massage=DBHandler.getMassage(DBHandler,3);




        if(isMyInfoIsEmpty()==true){
            Intent intent = new Intent(MainActivity.this, SignUp_Activity.class);
            startActivity(intent);
        }else{

            setContentView(R.layout.activity_main);
            signIn = (Button) findViewById(R.id.signIn);
            signIn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(MainActivity.this, Home_Activity.class);
                    startActivity(intent);
                }
            });

            /*signUp = (Button) findViewById(R.id.signUp);
            signUp.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(MainActivity.this, SignUp_Activity.class);
                            startActivity(intent);
                        }
                    }
            );*/

            Forgot_Password = (TextView) findViewById(R.id.forgot);
            Forgot_Password.setOnClickListener(
                    new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Intent intent = new Intent(MainActivity.this, Forgot_Password_Activity.class);
                            startActivity(intent);
                        }
                    }
            );
        }

    }

    public Boolean isMyInfoIsEmpty(){
        SignUp signUp=DBHandler.getUserInfo(DBHandler);
        if(signUp==null){
            return true;
        }
        else {
            return false;
        }
    }

}
