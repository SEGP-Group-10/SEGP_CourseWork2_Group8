package com.example.muzammil.prolife;


import android.os.HandlerThread;
import android.util.Log;

import com.example.muzammil.prolife.commclasses.Packet;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * Created by muzammil on 4/13/18.
 */

public class SocketThread extends HandlerThread{

    Socket socket=null;
    ObjectOutputStream outputStream;
    ObjectInputStream inputStream;

    public SocketThread() {
        super("SocketThread");
    }


    public static byte[] serialize(Object obj) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        ObjectOutputStream os = new ObjectOutputStream(out);
        os.writeObject(obj);
        return out.toByteArray();
    }

    public static Object deserialize(byte[] data) throws IOException, ClassNotFoundException {
        ByteArrayInputStream in = new ByteArrayInputStream(data);
        ObjectInputStream is = new ObjectInputStream(in);
        return is.readObject();
    }

    DataOutputStream dataOutputStream;
    DataInputStream dataInputStream;


    @Override
    public void run() {
        try {
            socket=new Socket("192.168.40.198",8888);
            Log.d("Socket","Conection created: "+socket.isConnected());
            dataOutputStream=new DataOutputStream(socket.getOutputStream());
            dataInputStream=new DataInputStream(socket.getInputStream());
            /*inputStream = new ObjectInputStream(socket.getInputStream());
            Log.d("Socket","InputStream obj created: ");
            outputStream=new ObjectOutputStream(socket.getOutputStream());
            Log.d("Socket","outputStream obj created: ");*/

            Thread writingThread=new Thread(new Runnable() {
                @Override
                public void run() {
                    Log.d("Socket","Writing Thread before while ");
                    while (socket.isConnected()){
                        Log.d("Socket","Writing Thread in while before writing packet");
                        if(MainActivity.outgoingPackets.size()>0){
                            try {

                                byte[] p=serialize(MainActivity.outgoingPackets.get(0));

                                dataOutputStream.write(p);
                                dataOutputStream.flush();

                                MainActivity.outgoingPackets.remove(0);
                                Log.d("Socket","Writing Thread after writing packet");
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }

                        if(socket.isClosed()){
                            break;
                        }

                        try {
                            sleep(15000);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            });

            writingThread.start();

            Thread readingSocket=new Thread(new Runnable() {
                @Override
                public void run() {
                    Log.d("Socket","Reading Thread before while ");
                    while (socket.isConnected()){
                        Log.d("Socket","Reading Thread in while before reading packet");
                        try {


                            byte[] b=new byte[10000];
                            dataInputStream.read(b,0,b.length);
                            Object object=deserialize(b);
                            Packet packet= (Packet) object;
                            MainActivity.incomingPackets.add(packet);
                            Log.d("Socket","Reading Thread after reading packet");

                        } catch (IOException e) {
                            e.printStackTrace();
                        } catch (ClassNotFoundException e) {
                            e.printStackTrace();
                        }

                        try {
                            sleep(500);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }

                        if(socket.isClosed()){
                            break;
                        }
                    }

                }
            });

            readingSocket.start();

            while (socket.isConnected()){

            }

            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }
}
