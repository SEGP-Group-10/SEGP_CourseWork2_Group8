package com.example.muzammil.prolife.commclasses;

public enum MassageType {
    TEXT,IMAGE
}
