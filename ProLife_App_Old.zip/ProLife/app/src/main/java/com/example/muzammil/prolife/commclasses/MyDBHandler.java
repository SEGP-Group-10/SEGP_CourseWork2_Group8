package com.example.muzammil.prolife.commclasses;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.CursorIndexOutOfBoundsException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

/**
 * Created by muzammil on 4/9/18.
 */

public class MyDBHandler extends SQLiteOpenHelper {

    public static final String DatabaseName = "DB.db";
    public static final String Myinfo_Table = "myinfo";
    public static final String Message_Table = "messages";
    public static final String Contact_Table = "contacts";

    // Massage Table columns information
    public static final String message_id="message_id";
    public static final String sender_no="sender_no";
    public static final String receiver_no="receiver_no";
    public static final String time_stamp="time_stamp";
    public static final String text_data="text_data";
    public static final String image_data="image_data";

    // My_info Table columns information
    public static final String myinfo_id="id";
    public static final String user_no="user_no";
    public static final String user_name="name";
    public static final String user_password="password";
    public static final String user_image="image";
    public static final String user_status="status";
    public static final String islogedin="isLogedIn";

    // Contact Table columns information
    public static final String contact_id="contact_id";
    public static final String contact_name="name";
    public static final String contact_no="no";
    public static final String contact_image="image";

    static final String Table_CREATE_Messages = "create table  messages ("+message_id+" INTEGER PRIMARY KEY AUTOINCREMENT ,"+sender_no+" String NOT NULL ,"+receiver_no+" String NOT NULL,"+time_stamp+" timestamp long,"+text_data+" text,"+image_data+" longblob)";

    static final String Table_CREATE_myInfo = "create table myinfo ("+myinfo_id+" INTEGER PRIMARY KEY AUTOINCREMENT,"+user_no+" String NOT NULL,"+user_name+" String NOT NULL,"+user_password+" String NOT NULL,"+user_image+" longblob,"+user_status+" text,"+islogedin+" String)";

    static final String Table_CREATE_Contacts = "create table contacts ("+contact_id+" INTEGER PRIMARY KEY AUTOINCREMENT,"+contact_name+" String NOT NULL ,"+ contact_no+" String NOT NULL,"+ contact_image+" longblob)";

    public MyDBHandler(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, DatabaseName, factory, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(Table_CREATE_Messages);
        sqLiteDatabase.execSQL(Table_CREATE_myInfo);
        sqLiteDatabase.execSQL(Table_CREATE_Contacts);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
      //  sqLiteDatabase.execSQL("Drop table if exists messages");
      //  sqLiteDatabase.execSQL(Table_CREATE_Messages);
    }

    public Boolean addUserInfo(MyDBHandler db, SignUp signup) {

        ContentValues values=new ContentValues();
        values.put(user_no,signup.getUserNo());
        values.put(user_name,signup.getName());
        values.put(user_password,signup.getPassword());
        values.put(user_image,signup.getImage());
        values.put(user_status,signup.getStatus());

        SQLiteDatabase sqLiteDatabase=db.getWritableDatabase();
        long isInserted=sqLiteDatabase.insert(Myinfo_Table,null,values);

        if (isInserted > 0) {
            Log.d("Database Operation", "Values Inserted");
            return true;
        } else {
            Log.d("Database Operation", "Sorry there was an error");
            return false;
        }
    }

    public Boolean removeUserInfo(MyDBHandler db) {

        SQLiteDatabase sqLiteDatabase=db.getWritableDatabase();
        long isDeleted=sqLiteDatabase.delete(Myinfo_Table,user_no+"=03002807360",null);

        if (isDeleted > 0) {
            Log.d("Database Operation", "Values Deleted");
            return true;
        } else {
            Log.d("Database Operation", "Sorry there was an error");
            return false;
        }
    }

    public Boolean updateUserInfo(MyDBHandler db, SignUp signup) {

        ContentValues values=new ContentValues();
        values.put(user_no,signup.getUserNo());
        values.put(user_name,signup.getName());
        values.put(user_password,signup.getPassword());
        values.put(user_image,signup.getImage());
        values.put(user_status,signup.getStatus());

        SQLiteDatabase sqLiteDatabase=db.getWritableDatabase();
        long isUpdateded=sqLiteDatabase.update(Myinfo_Table,values,user_no+"="+signup.getUserNo(),null);

        if (isUpdateded > 0) {
            Log.d("Database Operation", "Values Inserted");
            return true;
        } else {
            Log.d("Database Operation", "Sorry there was an error");
            return false;
        }
    }

    public SignUp getUserInfo(MyDBHandler db){

        SignUp signUp = null;

        SQLiteDatabase sqLiteDatabase=db.getReadableDatabase();
        Cursor c = sqLiteDatabase.rawQuery("Select * from myinfo where 1", null);
        try {
            c.moveToFirst();
            signUp = new SignUp(c.getString(c.getColumnIndex(user_no)), c.getString(c.getColumnIndex(user_password)), c.getString(c.getColumnIndex(user_name)), c.getBlob(c.getColumnIndex(user_image)), c.getString(c.getColumnIndex(user_status)));
        }catch (CursorIndexOutOfBoundsException e){

        }
        c.close();
        sqLiteDatabase.close();
        return signUp;
    }

    public Boolean isUserLogedIn(MyDBHandler db){
        SQLiteDatabase sqLiteDatabase=db.getReadableDatabase();
        Cursor c = sqLiteDatabase.rawQuery("Select "+islogedin+" from myinfo where 1", null);
        c.moveToFirst();
        try {
            if ((c.getString(c.getColumnIndex(islogedin))).toString().equals("true")) {
                return true;
            } else {
                return false;
            }
        }catch (CursorIndexOutOfBoundsException e){

        }
        return false;
    }

    public Boolean setUserLogedInInfo(MyDBHandler db, String isLogedIn,String userNo){
        ContentValues values=new ContentValues();
        values.put(islogedin,isLogedIn);

        SQLiteDatabase sqLiteDatabase=db.getWritableDatabase();
        long isUpdateded=sqLiteDatabase.update(Myinfo_Table,values,user_no+"="+userNo,null);

        if (isUpdateded > 0) {
            Log.d("Database Operation", "Values Inserted");
            return true;
        } else {
            Log.d("Database Operation", "Sorry there was an error");
            return false;
        }
    }

    public Boolean getUserLogedIn(MyDBHandler db, SignIn signIn){

        SQLiteDatabase sqLiteDatabase=db.getReadableDatabase();
        Cursor c = sqLiteDatabase.rawQuery("Select * from myinfo where 1", null);
        c.moveToFirst();

        try {
            if ((c.getString(c.getColumnIndex(user_no))).toString().equals(signIn.getUserNo()) && (c.getString(c.getColumnIndex(user_password))).toString().equals(signIn.getPassword())) {
                return true;
            } else {
                return false;
            }
        }catch (CursorIndexOutOfBoundsException e){

        }
        return false;
    }


    public Boolean addNewContact(MyDBHandler dbHandler , Contact contact){

        ContentValues values=new ContentValues();
        values.put(contact_name,contact.getName());
        values.put(contact_no,contact.getUser_No());
        values.put(contact_image,contact_image);

        SQLiteDatabase sqLiteDatabase=dbHandler.getWritableDatabase();
        long isInserted=sqLiteDatabase.insert(Contact_Table,null,values);

        if (isInserted > 0) {
            Log.d("Database Operation", "Values Inserted");
            return true;
        } else {
            Log.d("Database Operation", "Sorry there was an error");
            return false;
        }
    }

    public Contact getContact(MyDBHandler db,long contactId){

        Contact contact=null;

        SQLiteDatabase sqLiteDatabase=db.getReadableDatabase();
        Cursor c = sqLiteDatabase.rawQuery("Select * from contacts where contact_id="+contactId, null);
        c.moveToFirst();

        try {
            contact = new Contact(c.getInt(c.getColumnIndex(contact_id)), c.getString(c.getColumnIndex(contact_name)), c.getString(c.getColumnIndex(contact_no)), c.getBlob(c.getColumnIndex(contact_image)));
            Log.d("Database Operation","Contact Id= "+c.getInt(c.getColumnIndex(contact_id)));
            Log.d("Database Operation","Contact No = "+c.getString(c.getColumnIndex(contact_no)));
        }catch (CursorIndexOutOfBoundsException e){
            Log.d("Database Operation","CursorIndexOutOfBoundsException");
        }

        c.close();
        sqLiteDatabase.close();
        return contact;
    }

    public ArrayList<Contact> getContactList(MyDBHandler db) {
        ArrayList<Contact> contactList = new ArrayList<Contact>();

        Contact contact=null;

        SQLiteDatabase sqLiteDatabase=db.getReadableDatabase();
        Cursor c = sqLiteDatabase.rawQuery("Select * from contacts", null);
        try {
            c.moveToFirst();

            while (!c.isAfterLast()) {
                contact = new Contact(c.getInt(c.getColumnIndex(contact_id)), c.getString(c.getColumnIndex(contact_name)), c.getString(c.getColumnIndex(contact_no)), c.getBlob(c.getColumnIndex(contact_image)));
                contactList.add(contact);
                c.moveToNext();
            }
        }catch (CursorIndexOutOfBoundsException e){

        }
        c.close();
        sqLiteDatabase.close();

        return contactList;
    }

    public Boolean addNewMassage(MyDBHandler dbHandler , Massage message){

        ContentValues values=new ContentValues();
        values.put(sender_no,message.getSenderNo());
        values.put(receiver_no,message.getReceiverNo());
        values.put(text_data,message.getTextData());
        values.put(image_data,message.getImageData());

        SQLiteDatabase sqLiteDatabase=dbHandler.getWritableDatabase();
        long isInserted=sqLiteDatabase.insert(Message_Table,null,values);

        if (isInserted > 0) {
            Log.d("Database Operation", "Values Inserted");
            return true;
        } else {
            Log.d("Database Operation", "Sorry there was an error");
            return false;
        }
    }

    public Massage getMassage(MyDBHandler db,long massageId){

        Massage massage = null;

        SQLiteDatabase sqLiteDatabase=db.getReadableDatabase();
        Cursor c = sqLiteDatabase.rawQuery("Select * from messages where message_id="+massageId, null);
        try{
            c.moveToFirst();
            massage=new Massage(c.getLong(c.getColumnIndex(message_id)),c.getString(c.getColumnIndex(sender_no)),c.getString(c.getColumnIndex(receiver_no)),null,c.getString(c.getColumnIndex(text_data)),c.getBlob(c.getColumnIndex(image_data)));
            Log.d("Database Operation","Massage Id= "+c.getLong(c.getColumnIndex(message_id)));
            Log.d("Database Operation","Massage = "+c.getString(c.getColumnIndex(text_data)));
        }catch (CursorIndexOutOfBoundsException e){

        }

        c.close();
        sqLiteDatabase.close();
        return massage;
    }

    public ArrayList<Massage> getListMassages(MyDBHandler db, String senderNo, String recNo) {
        ArrayList<Massage> massagesList = new ArrayList<Massage>();
        Massage massage = null;

        SQLiteDatabase sqLiteDatabase=db.getWritableDatabase();
        Cursor c = sqLiteDatabase.rawQuery("select * from messages where ((sender_no="+senderNo+" and receiver_no="+recNo+") or (sender_no="+recNo+" and receiver_no="+senderNo+"))", null);

        try {
            c.moveToFirst();
            while (!c.isAfterLast()) {
                massage = new Massage(c.getLong(c.getColumnIndex(message_id)), c.getString(c.getColumnIndex(sender_no)), c.getString(c.getColumnIndex(receiver_no)), null, c.getString(c.getColumnIndex(text_data)), c.getBlob(c.getColumnIndex(image_data)));
                massagesList.add(massage);
                c.moveToNext();
            }
        }catch (CursorIndexOutOfBoundsException e){

        }
        c.close();
        sqLiteDatabase.close();

        return massagesList;
    }
}
