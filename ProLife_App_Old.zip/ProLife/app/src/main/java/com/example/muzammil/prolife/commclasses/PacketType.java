package com.example.muzammil.prolife.commclasses;

public enum PacketType {
    LOGIN,SIGNUP,MASSAGE,SIGNUP_RESPONSE
}
