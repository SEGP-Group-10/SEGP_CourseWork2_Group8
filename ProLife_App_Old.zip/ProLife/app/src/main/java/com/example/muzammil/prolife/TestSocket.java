package com.example.muzammil.prolife;

import android.os.AsyncTask;
import android.util.Log;

import com.example.muzammil.prolife.commclasses.Packet;
import com.example.muzammil.prolife.commclasses.PacketType;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * Created by muzammil on 4/5/18.
 */

public class TestSocket extends AsyncTask<Void,Void,Void> {

    Socket s;

    ObjectInputStream inputStream;
    ObjectOutputStream outputStream;

    @Override
    protected Void doInBackground(Void... voids) {

        Runnable readSocket=new Runnable() {
            @Override
            public void run() {
                Log.d("Socket","Reading Thread before while ");
                while (s.isConnected()){
                    Log.d("Socket","Reading Thread in while before reading packet");
                    try {
                        Packet packet= (Packet) inputStream.readObject();
                        MainActivity.incomingPackets.add(packet);
                        Log.d("Socket","Reading Thread after reading packet");
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }
                }
            }
        };

        Runnable writeSocket=new Runnable() {
            @Override
            public void run() {
                Log.d("Socket","Writing Thread before while ");
                while (s.isConnected()){
                    Log.d("Socket","Writing Thread in while before writing packet");
                    if(MainActivity.outgoingPackets.size()>0){
                        try {
                            outputStream.writeObject(MainActivity.outgoingPackets.get(1));
                            outputStream.flush();
                            MainActivity.outgoingPackets.remove(1);
                            Log.d("Socket","Writing Thread after writing packet");
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        };

        try {
            s=new Socket("192.168.40.198",8888);
            Log.d("Socket","Conection created: "+s.isConnected());
            inputStream=new ObjectInputStream(s.getInputStream());
            Log.d("Socket","InputStream obj created: ");
            outputStream=new ObjectOutputStream(s.getOutputStream());
            Log.d("Socket","outputStream obj created: ");

            /*Thread readingThread=new Thread(readSocket);
            readingThread.start();
            Log.d("Socket","Reading Thread created: ");

            Thread writingThread=new Thread(writeSocket);
            writingThread.start();
            Log.d("Socket","Writing Thread created: ");

            while (readingThread.isAlive() || writingThread.isAlive()){

            }*/

            Log.d("Socket","After Threads death.");

            inputStream.close();
            outputStream.close();
            s.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }
}
